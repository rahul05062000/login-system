from django.apps import AppConfig


class AaltuConfig(AppConfig):
    name = 'aaltu'
